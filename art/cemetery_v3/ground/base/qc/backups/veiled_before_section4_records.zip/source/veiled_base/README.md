# 雾中墓径大块底子：候选已交，混铺重复自查未通过

状态VEILED_BASE_STOPPED_VISIBLE_MIX_REPETITION。两块224×128的尺寸、36色、平均色、亮度标准差和所有相邻边检查达标；02内部偏平滑的区域反复出现，混铺形成可见块状节奏，已按需求停止。

根目录veiled_base_01/02.png为候选，未接入游戏。完整来源见manifest.json和../../qc/veiled_base_QA.md。01=新泥地生成原图，02=原生清理，03=半张平移，04=十字修复原图，05=主图原生组装，06=以主图为参考重画的变体原图，07=变体内部不规则选区与边缘保留。*_grid.json保存每个观察格边和中心取样点。

material_ops.py/prepare_material.py/assemble_main.py/assemble_variant_review.py只用于本轮来源复查。运行前需有Pillow/NumPy。没有程序造纹理，只有原生颜色归并、像素选择和排布；不改既有底子、贴花、过渡纹理或用户场景。113张既有图的保护哈希在protected_approved_assets.json。停止报告前恢复包在../../qc/backups/veiled_before_visual_stop.zip。
