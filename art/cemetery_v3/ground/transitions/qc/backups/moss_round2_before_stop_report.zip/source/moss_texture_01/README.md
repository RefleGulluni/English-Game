# 厚苔藓地01：裸铺重复明显，已按要求停止

状态为STOPPED_VISIBLE_REPETITION_NOT_ACCEPTED，不是已通过材质。尺寸、色表和接边数字符合要求，但团块／地衣组合循环可辨，部分团块有覆苔卵石感，跨接边界有3px地衣连通。没有换尺寸或换多图块方法。

完整制作索引见manifest.json，结论见../../qc/moss_texture_QA.md。01为初稿来源，02为调整后的选定来源，05为半张平移后的AI十字修复原图，03/04/06记录原生清理、平移、像素选择和色表；*_grid.json保存格边和中心取样坐标。预览只整数放大，原画未整体缩小。

material_ops.py、prepare_moss.py、finish_moss.py用于复查本轮，后续改动须等用户决定。protected_approved_assets.json记录96张已通过图的哈希，未改这些图或场景。内部恢复包在../../qc/backups/moss_before_stop_QA.zip及moss_before_wrapped_lichen_audit_note.zip。
